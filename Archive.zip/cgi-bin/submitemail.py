#!/usr/bin/env python3
import cgi
import pymysql

form = cgi.FieldStorage()
email =  form.getvalue('email')


conn = pymysql.connect(host='localhost', port=3306, user='anselmorris', passwd='Tue70tue0', db='lootstreak_database')

cur = conn.cursor()

cur.execute ("""
   UPDATE email_subscription
   SET email_address=%s
   WHERE Server=%s
""", (email, 'localhost'))

cur.close()
conn.close()