#!/usr/bin/env python3
import cgi
import pymysql
form = cgi.FieldStorage()
question1 = form.getvalue('question1')
question2 = form.getvalue('question2')
question3 = form.getvalue('question3')
question4 = form.getvalue('question4')


conn = pymysql.connect(host='localhost', port=3306, user='anselmorris', passwd='Tue70tue0', db='lootstreak_database')

cur = conn.cursor()

cur.execute ("""
   UPDATE email_subscription
   SET question_1=%s, question_2=%s, question_3=%s, question_4=%s
   WHERE Server=%s
""", (question1, question2, question3, question4, 'localhost'))

cur.close()
conn.close()